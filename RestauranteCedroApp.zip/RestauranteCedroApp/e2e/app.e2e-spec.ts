import { RestauranteCedroAppPage } from './app.po';

describe('restaurante-cedro-app App', function() {
  let page: RestauranteCedroAppPage;

  beforeEach(() => {
    page = new RestauranteCedroAppPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
