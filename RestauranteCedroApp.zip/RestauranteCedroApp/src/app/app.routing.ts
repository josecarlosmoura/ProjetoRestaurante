import { ModuleWithProviders } from '@angular/core';
import  {Routes, RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import { PratosComponent } from './components/pratos/pratos.component';
import { RestaurantesComponent } from './components/restaurantes/restaurantes.component';
import { HomeComponent } from './components/home/home.component';
import { CadastrorestaurantesComponent } from './components/cadastrorestaurantes/cadastrorestaurantes.component';
import { CadastropratosComponent } from './components/cadastropratos/cadastropratos.component';

const APP_ROUTES: Routes = [
    { path: '', component: HomeComponent },
    { path: 'pratos', component: PratosComponent },
    { path: 'restaurantes', component: RestaurantesComponent },
    { path: 'cadastrorestaurantes', component: CadastrorestaurantesComponent},
    { path: 'cadastropratos', component: CadastropratosComponent}
];

export const routing: ModuleWithProviders = RouterModule.forRoot(APP_ROUTES);