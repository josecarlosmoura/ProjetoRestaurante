import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { MaterializeModule } from 'angular2-materialize';
import { PratosComponent } from './components/pratos/pratos.component';
import { RestaurantesComponent } from './components/restaurantes/restaurantes.component';
import { HomeComponent } from './components/home/home.component';
import { routing } from './app.routing';
import { CadastrorestaurantesComponent } from './components/cadastrorestaurantes/cadastrorestaurantes.component';
import { CadastropratosComponent } from './components/cadastropratos/cadastropratos.component';

@NgModule({
  declarations: [
    AppComponent,
    PratosComponent,
    RestaurantesComponent,
    HomeComponent,
    CadastrorestaurantesComponent,
    CadastropratosComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    MaterializeModule,
    routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
