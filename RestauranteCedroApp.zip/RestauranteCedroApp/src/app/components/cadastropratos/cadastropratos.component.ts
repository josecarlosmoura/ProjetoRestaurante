import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cadastropratos',
  templateUrl: './cadastropratos.component.html',
  styleUrls: ['./cadastropratos.component.css']
})
export class CadastropratosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
