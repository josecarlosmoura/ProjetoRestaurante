import { Component, OnInit } from '@angular/core';

import { Http, Response, Headers } from '@angular/http';

@Component({
  selector: 'app-cadastrorestaurantes',
  templateUrl: './cadastrorestaurantes.component.html',
  styleUrls: ['./cadastrorestaurantes.component.css']
})
export class CadastrorestaurantesComponent implements OnInit {

  constructor(private http: Http) { }
  restauranteObj:Object = {};

  addNovoRestaurante = function(restaurante){
    this.restauranteObj = {
      "nome": restaurante.nome
    }
    this.http.post("https://restaurantecedro-api.azurewebsites.net/api/Restaurante", this.restauranteObj).subscribe((
      res:Response) => {console.log(res)}
    )
  }

  ngOnInit() {
  }

}
